import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

interface ReportItem {
  id: string;
  reporter_id: string;
  reported_user_id: string | null;
  message_id: string | null;
  reason: string;
  description: string | null;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  moderator_id: string | null;
  moderator_notes: string | null;
  created_at: string;
  updated_at: string;
  reporter?: { username: string | null; display_name: string | null };
  reported_user?: { username: string | null; display_name: string | null };
}

interface Stats {
  total_users: number;
  active_today: number;
  pending_reports: number;
  total_reports: number;
  total_connections: number;
  total_messages: number;
}

type Tab = 'overview' | 'reports' | 'users';

export default function AdminDashboard() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [stats, setStats] = useState<Stats>({
    total_users: 0, active_today: 0, pending_reports: 0,
    total_reports: 0, total_connections: 0, total_messages: 0,
  });
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchStats = useCallback(async () => {
    try {
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      const { count: pendingReports } = await supabase
        .from('reports')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      const { count: totalReports } = await supabase
        .from('reports')
        .select('*', { count: 'exact', head: true });

      const { count: totalConnections } = await supabase
        .from('friendship_requests')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'accepted');

      const { count: totalMessages } = await supabase
        .from('messages')
        .select('*', { count: 'exact', head: true });

      setStats({
        total_users: totalUsers || 0,
        active_today: 0, // Would need last_active filter
        pending_reports: pendingReports || 0,
        total_reports: totalReports || 0,
        total_connections: totalConnections || 0,
        total_messages: totalMessages || 0,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  }, []);

  const fetchReports = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('reports')
        .select(`
          *,
          reporter:profiles!reports_reporter_id_fkey(username, display_name),
          reported_user:profiles!reports_reported_user_id_fkey(username, display_name)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setReports(data || []);
    } catch (error: any) {
      console.error('Error fetching reports:', error);
    }
  }, []);

  useEffect(() => {
    if (profile?.role !== 'admin' && profile?.role !== 'moderator') return;
    setLoading(true);
    Promise.all([fetchStats(), fetchReports()]).finally(() => setLoading(false));
  }, [profile, fetchStats, fetchReports]);

  const updateReportStatus = async (reportId: string, status: 'investigating' | 'resolved' | 'dismissed', notes?: string) => {
    if (!profile) return;

    try {
      const { error } = await supabase
        .from('reports')
        .update({
          status,
          moderator_id: profile.id,
          moderator_notes: notes || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', reportId);

      if (error) throw error;

      // Log the moderation action
      await supabase
        .from('moderation_audit_logs')
        .insert({
          moderator_id: profile.id,
          action: `report_${status}`,
          target_type: 'report',
          target_id: reportId,
          details: { previous_status: reports.find(r => r.id === reportId)?.status },
        });

      toast.success(`Report ${status}`);
      fetchReports();
      fetchStats();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update report');
    }
  };

  const suspendUser = async (userId: string, reason: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          is_suspended: true,
          suspend_reason: reason,
        })
        .eq('id', userId);

      if (error) throw error;

      await supabase.from('moderation_audit_logs').insert({
        moderator_id: profile!.id,
        action: 'user_suspended',
        target_type: 'user',
        target_id: userId,
        details: { reason },
      });

      toast.success('User suspended');
    } catch (error: any) {
      toast.error(error.message || 'Failed to suspend user');
    }
  };

  if (!profile || (profile.role !== 'admin' && profile.role !== 'moderator')) {
    return (
      <div className="page-container">
        <div className="content-container text-center py-12">
          <h1 className="section-title">Access Denied</h1>
          <p className="text-jerry-300">You do not have permission to access this page.</p>
        </div>
      </div>
    );
  }

  const tabs: { key: Tab; label: string }[] = [
    { key: 'overview', label: 'Overview' },
    { key: 'reports', label: `Reports (${stats.pending_reports})` },
    { key: 'users', label: 'Users' },
  ];

  return (
    <div className="page-container">
      <div className="content-container max-w-6xl">
        <div className="flex items-center justify-between mb-6">
          <h1 className="section-title mb-0">Admin Dashboard</h1>
          <span className="badge-primary">{profile.role}</span>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 glass-card p-1">
          {tabs.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-all ${
                activeTab === key
                  ? 'bg-jerry-500/20 text-jerry-200'
                  : 'text-jerry-400 hover:text-jerry-300'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="glass-card p-12 text-center">
            <p className="text-jerry-300">Loading dashboard...</p>
          </div>
        ) : activeTab === 'overview' ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              { label: 'Total Users', value: stats.total_users },
              { label: 'Active Today', value: stats.active_today },
              { label: 'Pending Reports', value: stats.pending_reports },
              { label: 'Total Reports', value: stats.total_reports },
              { label: 'Connections Made', value: stats.total_connections },
              { label: 'Messages Sent', value: stats.total_messages },
            ].map(({ label, value }) => (
              <div key={label} className="glass-card p-4 text-center">
                <p className="text-3xl font-display font-bold text-white">{value}</p>
                <p className="text-jerry-400 text-sm mt-1">{label}</p>
              </div>
            ))}
          </div>
        ) : activeTab === 'reports' ? (
          <div className="space-y-3">
            {reports.length === 0 ? (
              <div className="glass-card p-12 text-center">
                <p className="text-jerry-300">No reports to review</p>
              </div>
            ) : (
              reports.map(report => (
                <div key={report.id} className="glass-card p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className={`badge ${
                        report.status === 'pending' ? 'badge-warning' :
                        report.status === 'investigating' ? 'badge-primary' :
                        report.status === 'resolved' ? 'badge-success' : 'badge-danger'
                      }`}>{report.status}</span>
                      <p className="text-white text-sm font-medium mt-2">{report.reason}</p>
                      {report.description && (
                        <p className="text-jerry-300 text-xs mt-1">{report.description}</p>
                      )}
                    </div>
                    <span className="text-jerry-400 text-xs">
                      {new Date(report.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-jerry-400 mb-3">
                    {report.reporter && <span>Reported by: {report.reporter.display_name || report.reporter.username}</span>}
                    {report.reported_user && <span>Reported user: {report.reported_user.display_name || report.reported_user.username}</span>}
                  </div>
                  {report.status === 'pending' || report.status === 'investigating' ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => updateReportStatus(report.id, 'investigating')}
                        className="btn-primary text-xs py-1.5 px-3"
                      >
                        Investigate
                      </button>
                      <button
                        onClick={() => updateReportStatus(report.id, 'resolved', 'Violation confirmed')}
                        className="btn-danger text-xs py-1.5 px-3"
                      >
                        Resolve & Warn
                      </button>
                      <button
                        onClick={() => updateReportStatus(report.id, 'dismissed', 'No violation found')}
                        className="btn-secondary text-xs py-1.5 px-3"
                      >
                        Dismiss
                      </button>
                      {report.reported_user_id && (
                        <button
                          onClick={() => suspendUser(report.reported_user_id!, 'Violation of community guidelines')}
                          className="btn-danger text-xs py-1.5 px-3"
                        >
                          Suspend User
                        </button>
                      )}
                    </div>
                  ) : (
                    <p className="text-jerry-400 text-xs italic">
                      {report.moderator_notes || `Action taken by moderator`}
                    </p>
                  )}
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="glass-card p-12 text-center">
            <p className="text-jerry-300">User management interface</p>
            <p className="text-jerry-400 text-sm mt-2">
              User search, suspension management, and activity overview would appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}