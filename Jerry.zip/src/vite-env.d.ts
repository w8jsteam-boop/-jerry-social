/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  readonly VITE_APP_NAME: string;
  readonly VITE_APP_URL: string;
  readonly VITE_APP_DESCRIPTION: string;
  readonly VITE_AVATAR_BUCKET: string;
  readonly VITE_MEDIA_BUCKET: string;
  readonly VITE_ENABLE_OAUTH: string;
  readonly VITE_ENABLE_EMAIL_VERIFICATION: string;
  readonly VITE_MAX_MESSAGE_LENGTH: string;
  readonly VITE_RATE_LIMIT_MESSAGES: string;
  readonly VITE_RATE_LIMIT_REQUESTS: string;
  readonly VITE_REALTIME_ENABLED: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}