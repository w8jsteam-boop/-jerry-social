import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!email.trim() || !password) {
      setError('Please enter your email and password');
      setLoading(false);
      return;
    }

    const result = await signIn(email, password);
    
    if (!result.error) {
      navigate('/discover');
    }
    setLoading(false);
  };

  const inputClass = "w-full px-4 py-3 bg-white/5 border border-jerry-400/20 text-white placeholder-jerry-200/40 rounded-xl focus:outline-none focus:border-jerry-400/60 focus:bg-white/10 focus:ring-1 focus:ring-jerry-400/30 transition-all duration-200";

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-jerry-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/3 w-96 h-96 bg-jerry-400/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-jerry-500 to-jerry-700 flex items-center justify-center shadow-lg shadow-jerry-500/30">
              <svg viewBox="0 0 24 24" className="w-7 h-7 text-white" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
            </div>
          </Link>
          <h1 className="text-3xl font-display font-bold text-white">Welcome back</h1>
          <p className="text-jerry-200/70 mt-2">Sign in to your JERRY account</p>
        </div>

        <div className="glass-card p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-jerry-200 mb-2">Email address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className={inputClass}
                placeholder="you@example.com"
                required
                autoComplete="email"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-jerry-200 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className={inputClass}
                placeholder="Your password"
                required
                autoComplete="current-password"
              />
            </div>
            {error && <p className="text-red-400 text-sm">{error}</p>}
            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <Link to="/forgot-password" className="text-jerry-300 hover:text-jerry-200 text-sm underline underline-offset-2">
              Forgot your password?
            </Link>
          </div>
        </div>

        <p className="text-center mt-6 text-jerry-300 text-sm">
          Don't have an account?{' '}
          <Link to="/signup" className="text-jerry-200 hover:text-white font-medium underline underline-offset-2">
            Join JERRY
          </Link>
        </p>
      </div>
    </div>
  );
}