export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Omit<Profile, 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Profile, 'id'>>;
      };
      friendship_requests: {
        Row: FriendshipRequest;
        Insert: Omit<FriendshipRequest, 'created_at' | 'updated_at'>;
        Update: Partial<Omit<FriendshipRequest, 'id'>>;
      };
      conversations: {
        Row: Conversation;
        Insert: Omit<Conversation, 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Conversation, 'id'>>;
      };
      conversation_members: {
        Row: ConversationMember;
        Insert: Omit<ConversationMember, 'joined_at'>;
        Update: Partial<Omit<ConversationMember, 'id'>>;
      };
      messages: {
        Row: Message;
        Insert: Omit<Message, 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Message, 'id'>>;
      };
      notifications: {
        Row: Notification;
        Insert: Omit<Notification, 'created_at'>;
        Update: Partial<Omit<Notification, 'id'>>;
      };
      blocks: {
        Row: Block;
        Insert: Omit<Block, 'created_at'>;
        Update: Partial<Omit<Block, 'id'>>;
      };
      reports: {
        Row: Report;
        Insert: Omit<Report, 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Report, 'id'>>;
      };
      moderation_audit_logs: {
        Row: ModerationAuditLog;
        Insert: Omit<ModerationAuditLog, 'created_at'>;
        Update: Partial<Omit<ModerationAuditLog, 'id'>>;
      };
    };
    Views: {};
    Functions: {};
    Enums: {
      friendship_status: 'pending' | 'accepted' | 'declined' | 'blocked';
      message_type: 'text' | 'image' | 'system';
      notification_type: 'friend_request' | 'friend_accepted' | 'new_message' | 'report_update';
      report_status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
      user_role: 'user' | 'moderator' | 'admin';
      profile_visibility: 'public' | 'connections' | 'private';
    };
  };
}

export interface Profile {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  interests: string[] | null;
  language: string | null;
  age_verified: boolean;
  birth_date: string | null;
  visibility: 'public' | 'connections' | 'private';
  role: 'user' | 'moderator' | 'admin';
  is_suspended: boolean;
  suspend_reason: string | null;
  last_active: string | null;
  created_at: string;
  updated_at: string;
}

export interface FriendshipRequest {
  id: string;
  sender_id: string;
  receiver_id: string;
  status: 'pending' | 'accepted' | 'declined' | 'blocked';
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  created_at: string;
  updated_at: string;
  last_message_at: string | null;
  last_message_preview: string | null;
}

export interface ConversationMember {
  id: string;
  conversation_id: string;
  user_id: string;
  joined_at: string;
  last_read_at: string | null;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  type: 'text' | 'image' | 'system';
  read_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'friend_request' | 'friend_accepted' | 'new_message' | 'report_update';
  title: string;
  body: string | null;
  data: Record<string, unknown> | null;
  read: boolean;
  created_at: string;
}

export interface Block {
  id: string;
  blocker_id: string;
  blocked_id: string;
  reason: string | null;
  created_at: string;
}

export interface Report {
  id: string;
  reporter_id: string;
  reported_user_id: string | null;
  message_id: string | null;
  reason: string;
  description: string | null;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  moderator_id: string | null;
  moderator_notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface ModerationAuditLog {
  id: string;
  moderator_id: string;
  action: string;
  target_type: string;
  target_id: string;
  details: Record<string, unknown> | null;
  created_at: string;
}

export type Tables = Database['public']['Tables'];