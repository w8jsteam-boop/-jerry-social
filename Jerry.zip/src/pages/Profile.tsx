import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const INTEREST_OPTIONS = [
  'Art', 'Music', 'Technology', 'Travel', 'Fitness', 'Reading',
  'Gaming', 'Cooking', 'Photography', 'Nature', 'Sports', 'Movies',
  'Science', 'Fashion', 'Dancing', 'Writing', 'Coding', 'Design'
];

const LANGUAGE_OPTIONS = [
  'English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese',
  'Japanese', 'Korean', 'Chinese', 'Arabic', 'Hindi', 'Russian'
];

export default function Profile() {
  const { user, profile, signOut, updateProfile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    display_name: profile?.display_name || '',
    username: profile?.username || '',
    bio: profile?.bio || '',
    interests: profile?.interests || [],
    language: profile?.language || 'English',
    visibility: profile?.visibility || 'public',
  });

  const handleSave = async () => {
    setSaving(true);
    const result = await updateProfile(editForm);
    if (!result.error) {
      setIsEditing(false);
      refreshProfile();
    }
    setSaving(false);
  };

  const toggleInterest = (interest: string) => {
    setEditForm(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest],
    }));
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleExportData = async () => {
    toast.success('Data export started. You will receive an email when ready.');
  };

  const handleDeleteAccount = () => {
    if (window.confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      toast.success('Account deletion requested. Check your email to confirm.');
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image must be under 2MB');
      return;
    }

    toast.success('Avatar upload requires Supabase storage configuration');
  };

  if (!profile) {
    return (
      <div className="page-container">
        <div className="content-container text-center py-12">
          <p className="text-jerry-300">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="content-container max-w-2xl">
        {/* Profile Header */}
        <div className="glass-card p-6 md:p-8 mb-6 text-center">
          <div className="relative inline-block mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-jerry-400 to-jerry-600 flex items-center justify-center text-3xl font-bold mx-auto shadow-lg shadow-jerry-500/20">
              {profile.avatar_url ? (
                <img src={profile.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
              ) : (
                (profile.display_name || profile.username || '?').charAt(0).toUpperCase()
              )}
            </div>
            {isEditing && (
              <label className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-jerry-500 flex items-center justify-center cursor-pointer hover:bg-jerry-400 transition-colors shadow-md">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <input type="file" accept="image/*" onChange={handleAvatarUpload} className="hidden" />
              </label>
            )}
          </div>
          <h1 className="text-2xl font-display font-bold text-white">
            {profile.display_name || profile.username || 'Anonymous'}
          </h1>
          {profile.username && (
            <p className="text-jerry-400 mt-1">@{profile.username}</p>
          )}
          <div className="flex items-center justify-center gap-4 mt-3 text-sm text-jerry-300/80">
            <span>{profile.language || 'No language set'}</span>
            <span>•</span>
            <span className="capitalize">{profile.visibility} profile</span>
            {profile.age_verified && (
              <>
                <span>•</span>
                <span className="text-green-400">✓ Verified 18+</span>
              </>
            )}
          </div>
        </div>

        {isEditing ? (
          /* Edit Mode */
          <div className="glass-card p-6 md:p-8 space-y-6">
            <h2 className="text-lg font-semibold text-white">Edit Profile</h2>

            <div>
              <label className="input-label">Display name</label>
              <input
                type="text"
                value={editForm.display_name}
                onChange={e => setEditForm(prev => ({ ...prev, display_name: e.target.value }))}
                className="input-field"
                placeholder="Your display name"
              />
            </div>

            <div>
              <label className="input-label">Username</label>
              <input
                type="text"
                value={editForm.username}
                onChange={e => setEditForm(prev => ({ ...prev, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') }))}
                className="input-field"
                placeholder="username"
              />
            </div>

            <div>
              <label className="input-label">Bio</label>
              <textarea
                value={editForm.bio}
                onChange={e => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                className="input-field min-h-[100px] resize-none"
                placeholder="Tell others about yourself..."
                maxLength={500}
              />
              <p className="text-jerry-400 text-xs mt-1">{editForm.bio.length}/500</p>
            </div>

            <div>
              <label className="input-label">Interests</label>
              <div className="flex flex-wrap gap-2">
                {INTEREST_OPTIONS.map(interest => (
                  <button
                    key={interest}
                    onClick={() => toggleInterest(interest)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                      editForm.interests.includes(interest)
                        ? 'bg-jerry-500/30 text-jerry-200 border border-jerry-400/50'
                        : 'bg-jerry-900/30 text-jerry-300/60 border border-jerry-800/30 hover:bg-jerry-800/30'
                    }`}
                  >
                    {interest}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="input-label">Language</label>
              <select
                value={editForm.language}
                onChange={e => setEditForm(prev => ({ ...prev, language: e.target.value }))}
                className="input-field"
              >
                {LANGUAGE_OPTIONS.map(lang => (
                  <option key={lang} value={lang}>{lang}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="input-label">Profile visibility</label>
              <div className="grid grid-cols-3 gap-2">
                {(['public', 'connections', 'private'] as const).map(v => (
                  <button
                    key={v}
                    onClick={() => setEditForm(prev => ({ ...prev, visibility: v }))}
                    className={`py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                      editForm.visibility === v
                        ? 'bg-jerry-500/20 text-jerry-200 border border-jerry-400/50'
                        : 'bg-jerry-900/30 text-jerry-300/60 border border-jerry-800/30'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-glass-heavy">
              <button onClick={() => setIsEditing(false)} className="btn-secondary flex-1">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        ) : (
          /* View Mode */
          <>
            {/* Bio */}
            {profile.bio && (
              <div className="glass-card p-6 mb-4">
                <h3 className="text-sm font-medium text-jerry-200 mb-2">About</h3>
                <p className="text-white/80 text-sm leading-relaxed">{profile.bio}</p>
              </div>
            )}

            {/* Interests */}
            {profile.interests && profile.interests.length > 0 && (
              <div className="glass-card p-6 mb-4">
                <h3 className="text-sm font-medium text-jerry-200 mb-3">Interests</h3>
                <div className="flex flex-wrap gap-2">
                  {profile.interests.map(i => (
                    <span key={i} className="badge-primary">{i}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="glass-card p-6 mb-4 space-y-3">
              <button onClick={() => setIsEditing(true)} className="btn-primary w-full">
                Edit Profile
              </button>
              <Link to="/settings" className="btn-secondary w-full block text-center">
                Account Settings
              </Link>
            </div>

            <div className="glass-card p-6 space-y-3">
              <h3 className="text-sm font-medium text-jerry-200 mb-3">Account</h3>
              <button onClick={handleExportData} className="btn-secondary w-full text-sm">
                Export My Data
              </button>
              <button onClick={handleSignOut} className="btn-danger w-full text-sm">
                Sign Out
              </button>
              <button onClick={handleDeleteAccount} className="btn-danger w-full text-sm bg-red-600/10">
                Delete Account
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}