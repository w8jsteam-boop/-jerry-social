import React from 'react';
import clsx from 'clsx';

interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'circular' | 'rectangular' | 'card';
  width?: string | number;
  height?: string | number;
}

export function Skeleton({ className, variant = 'text', width, height }: SkeletonProps) {
  const baseClasses = 'skeleton';
  
  const variantClasses = {
    text: 'h-4 w-full rounded',
    circular: 'rounded-full',
    rectangular: 'rounded-lg',
    card: 'rounded-2xl h-48 w-full',
  };

  return (
    <div
      className={clsx(baseClasses, variantClasses[variant], className)}
      style={{ width, height }}
      role="status"
      aria-label="Loading"
    />
  );
}

export function ProfileCardSkeleton() {
  return (
    <div className="glass-card p-4 space-y-3 animate-in">
      <div className="flex items-center gap-3">
        <Skeleton variant="circular" width={48} height={48} />
        <div className="flex-1 space-y-2">
          <Skeleton width="60%" />
          <Skeleton width="40%" />
        </div>
      </div>
      <Skeleton variant="rectangular" height={60} />
      <div className="flex gap-2">
        <Skeleton width={60} height={24} variant="rectangular" />
        <Skeleton width={60} height={24} variant="rectangular" />
        <Skeleton width={60} height={24} variant="rectangular" />
      </div>
      <Skeleton variant="rectangular" height={40} />
    </div>
  );
}

export function MessageSkeleton() {
  return (
    <div className="space-y-4 p-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className={clsx('flex gap-3', i % 2 === 0 ? 'justify-end' : '')}>
          {i % 2 !== 0 && <Skeleton variant="circular" width={32} height={32} />}
          <Skeleton
            width={i % 2 === 0 ? '50%' : '60%'}
            height={48}
            variant="rectangular"
            className={clsx(i % 2 === 0 ? 'rounded-l-xl rounded-tr-xl' : 'rounded-r-xl rounded-tl-xl')}
          />
          {i % 2 === 0 && <Skeleton variant="circular" width={32} height={32} />}
        </div>
      ))}
    </div>
  );
}

export function ConversationListSkeleton() {
  return (
    <div className="space-y-2 p-4">
      {[1, 2, 3, 4, 5].map((i) => (
        <div key={i} className="flex items-center gap-3 p-3">
          <Skeleton variant="circular" width={48} height={48} />
          <div className="flex-1 space-y-2">
            <Skeleton width="40%" />
            <Skeleton width="70%" />
          </div>
        </div>
      ))}
    </div>
  );
}