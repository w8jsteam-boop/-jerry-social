export interface User {
  id: string;
  email: string;
  created_at: string;
}

export interface AuthState {
  user: User | null;
  profile: Profile | null;
  session: any | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

export interface Profile {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  interests: string[];
  language: string;
  age_verified: boolean;
  visibility: 'public' | 'connections' | 'private';
  role: 'user' | 'moderator' | 'admin';
  is_suspended: boolean;
  last_active: string | null;
  created_at: string;
}

export interface FriendRequest {
  id: string;
  sender_id: string;
  receiver_id: string;
  status: 'pending' | 'accepted' | 'declined' | 'blocked';
  sender?: Profile;
  receiver?: Profile;
  created_at: string;
}

export interface Conversation {
  id: string;
  created_at: string;
  last_message_at: string | null;
  last_message_preview: string | null;
  members: Profile[];
  unread_count: number;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  type: 'text' | 'image' | 'system';
  read_at: string | null;
  sender?: Profile;
  created_at: string;
}

export interface Notification {
  id: string;
  type: 'friend_request' | 'friend_accepted' | 'new_message' | 'report_update';
  title: string;
  body: string | null;
  read: boolean;
  data: any;
  created_at: string;
}

export interface ThemeConfig {
  mode: 'dark' | 'light';
  toggle: () => void;
}