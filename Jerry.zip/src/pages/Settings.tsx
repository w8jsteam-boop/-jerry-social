import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';

export default function Settings() {
  const { user, profile, updateProfile } = useAuth();
  const { isDark, toggle } = useTheme();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [messagePreviewEnabled, setMessagePreviewEnabled] = useState(true);
  const [saving, setSaving] = useState(false);

  const handleNotificationToggle = async () => {
    setSaving(true);
    setNotificationsEnabled(prev => !prev);
    toast.success('Notification preferences updated');
    setSaving(false);
  };

  const handlePrivacyUpdate = async (field: string, value: string) => {
    setSaving(true);
    await updateProfile({ [field]: value } as any);
    setSaving(false);
  };

  return (
    <div className="page-container">
      <div className="content-container max-w-2xl">
        <h1 className="section-title">Settings</h1>

        {/* Profile Settings */}
        <section className="glass-card p-6 mb-4">
          <h2 className="text-lg font-semibold text-white mb-4">Profile</h2>
          <Link to="/profile" className="btn-secondary w-full text-sm">
            Edit Profile
          </Link>
        </section>

        {/* Appearance */}
        <section className="glass-card p-6 mb-4">
          <h2 className="text-lg font-semibold text-white mb-4">Appearance</h2>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white text-sm">Dark mode</p>
              <p className="text-jerry-400 text-xs mt-0.5">{isDark ? 'Dark theme active' : 'Light theme active'}</p>
            </div>
            <button
              onClick={toggle}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                isDark ? 'bg-jerry-500' : 'bg-jerry-800'
              }`}
              role="switch"
              aria-checked={isDark}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                isDark ? 'translate-x-6' : ''
              }`} />
            </button>
          </div>
        </section>

        {/* Notifications */}
        <section className="glass-card p-6 mb-4">
          <h2 className="text-lg font-semibold text-white mb-4">Notifications</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm">Push notifications</p>
                <p className="text-jerry-400 text-xs mt-0.5">Receive alerts for new messages and requests</p>
              </div>
              <button
                onClick={handleNotificationToggle}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  notificationsEnabled ? 'bg-jerry-500' : 'bg-jerry-800'
                }`}
                role="switch"
                aria-checked={notificationsEnabled}
              >
                <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  notificationsEnabled ? 'translate-x-6' : ''
                }`} />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm">Message previews</p>
                <p className="text-jerry-400 text-xs mt-0.5">Show message content in notifications</p>
              </div>
              <button
                onClick={() => setMessagePreviewEnabled(prev => !prev)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  messagePreviewEnabled ? 'bg-jerry-500' : 'bg-jerry-800'
                }`}
                role="switch"
                aria-checked={messagePreviewEnabled}
              >
                <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  messagePreviewEnabled ? 'translate-x-6' : ''
                }`} />
              </button>
            </div>
          </div>
        </section>

        {/* Privacy */}
        <section className="glass-card p-6 mb-4">
          <h2 className="text-lg font-semibold text-white mb-4">Privacy</h2>
          <div className="space-y-4">
            <div>
              <label className="input-label">Profile visibility</label>
              <select
                value={profile?.visibility || 'public'}
                onChange={e => handlePrivacyUpdate('visibility', e.target.value)}
                className="input-field"
                disabled={saving}
              >
                <option value="public">Public - visible to everyone</option>
                <option value="connections">Connections only</option>
                <option value="private">Private - not discoverable</option>
              </select>
            </div>
            <Link to="/blocked" className="text-jerry-300 hover:text-white text-sm underline underline-offset-2 block">
              Manage blocked users
            </Link>
          </div>
        </section>

        {/* Account */}
        <section className="glass-card p-6 mb-4">
          <h2 className="text-lg font-semibold text-white mb-4">Account</h2>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center py-2">
              <span className="text-jerry-200">Email</span>
              <span className="text-white">{user?.email}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-jerry-200">Member since</span>
              <span className="text-white">
                {user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
              </span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-jerry-200">Account type</span>
              <span className="badge-primary">{profile?.role || 'user'}</span>
            </div>
          </div>
        </section>

        {/* Legal Links */}
        <section className="glass-card p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Legal & Support</h2>
          <div className="space-y-2">
            <Link to="/privacy" className="block text-jerry-300 hover:text-white text-sm py-1">Privacy Policy</Link>
            <Link to="/terms" className="block text-jerry-300 hover:text-white text-sm py-1">Terms of Service</Link>
            <Link to="/guidelines" className="block text-jerry-300 hover:text-white text-sm py-1">Community Guidelines</Link>
            <Link to="/contact" className="block text-jerry-300 hover:text-white text-sm py-1">Contact & Support</Link>
          </div>
        </section>
      </div>
    </div>
  );
}