# JERRY - Private Social Connection Platform

A private, secure social connection platform for adults 18+. Built with React, TypeScript, and Supabase.

## Features

- **Private Profiles** - Full control over who sees your information
- **Age Verification** - Strict 18+ policy with secure verification
- **Smart Discovery** - Find people by interests, language, and preferences
- **Friendship Requests** - Send, accept, decline, and manage connections
- **Real-time Chat** - Private messaging with mutual consent
- **Notifications** - Real-time alerts for requests and messages
- **Privacy Controls** - Block users, report abuse, manage visibility
- **Admin Dashboard** - Moderation tools and platform management
- **PWA Support** - Install as a mobile app
- **Dark/Light Theme** - Customizable appearance

## Prerequisites

- **Node.js** 18+ and npm
- **Supabase** account (free tier works great)
- Basic familiarity with the terminal

## Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/yourusername/jerry.git
cd jerry
npm install
```

### 2. Set Up Supabase

1. Go to [supabase.com](https://supabase.com) and create a new project
2. In the SQL Editor, run the contents of `supabase/migrations/001_schema.sql`
3. This creates all tables, indexes, triggers, and security policies

### 3. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your Supabase project credentials:

| Variable | Description | Where to Find |
|----------|-------------|---------------|
| `VITE_SUPABASE_URL` | Your Supabase project URL | Supabase Dashboard → Settings → API |
| `VITE_SUPABASE_ANON_KEY` | Public anonymous key | Supabase Dashboard → Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Server-side only (keep secret!) | Supabase Dashboard → Settings → API |

### 4. Run Locally

```bash
npm run dev
```

Open http://localhost:3000 in your browser.

### 5. Build for Production

```bash
npm run build
```

The output goes to the `dist/` folder.

## Project Structure

```
jerry/
├── public/
│   ├── favicon.svg          # Original JERRY icon
│   ├── manifest.json         # PWA manifest
│   ├── sw.js                 # Service worker
│   └── icons/                # App icons (generate these)
├── supabase/
│   └── migrations/
│       └── 001_schema.sql    # Complete database schema
├── src/
│   ├── components/
│   │   ├── Layout/           # App layout, navigation
│   │   └── UI/               # Reusable UI components
│   ├── contexts/
│   │   ├── AuthContext.tsx    # Authentication state
│   │   └── ThemeContext.tsx   # Theme management
│   ├── lib/
│   │   └── supabase.ts       # Supabase client
│   ├── pages/
│   │   ├── auth/             # Login, Signup
│   │   ├── Landing.tsx       # Landing page
│   │   ├── Discover.tsx      # Profile discovery
│   │   ├── Connections.tsx   # Friendship management
│   │   ├── Messages.tsx      # Real-time chat
│   │   ├── Notifications.tsx # Notification center
│   │   ├── Profile.tsx       # User profile
│   │   ├── Settings.tsx      # Account settings
│   │   ├── AdminDashboard.tsx # Moderation tools
│   │   └── InfoPage.tsx      # Legal/support pages
│   ├── types/                # TypeScript types
│   ├── App.tsx               # Main app with routing
│   ├── main.tsx              # Entry point
│   └── index.css             # Global styles + design system
├── .env.example              # Environment template
├── package.json
├── tsconfig.json
├── tailwind.config.js        # Styling configuration
└── vite.config.ts            # Build configuration
```

## Database Design

### Core Tables

| Table | Purpose |
|-------|---------|
| `profiles` | User profiles with visibility controls |
| `friendship_requests` | Connection requests and status |
| `conversations` | Chat conversations |
| `conversation_members` | Conversation participants |
| `messages` | Private messages |
| `notifications` | User notifications |
| `blocks` | Blocked users |
| `reports` | Abuse reports |
| `moderation_audit_logs` | Moderation actions |

### Security

- **Row Level Security (RLS)** is enforced on all tables
- Users can only access their own data
- Messages are only visible to conversation members
- Blocked users cannot send messages to each other
- Moderators have limited elevated access

## Deploying to Production

### Option 1: Vercel (Recommended)

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) and import your repository
3. Add environment variables (from `.env`)
4. Deploy

### Option 2: Netlify

1. Connect your GitHub repository
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Add environment variables

### Option 3: Traditional Hosting

```bash
npm run build
# Upload the dist/ folder to your web server
```

Configure your web server to:
- Serve `index.html` for all routes (SPA)
- Serve static files from the `dist` folder
- Enable HTTPS

## PWA Installation

Once deployed, users can install JERRY as a mobile app:

- **Android** (Chrome): Tap "Add to Home Screen"
- **iOS** (Safari): Tap Share → "Add to Home Screen"

The PWA includes:
- Offline support for cached pages
- App-like navigation
- Push notification support (requires additional setup)

## Testing Main Flows

1. **Registration**: Visit `/signup`, complete the 3-step process (account → age verification → profile)
2. **Discovery**: Visit `/discover`, search/filter users, send friend requests
3. **Connections**: Visit `/connections`, accept/receive requests
4. **Messaging**: Once connected, visit `/messages` and start chatting
5. **Notifications**: Receive alerts for friend requests and messages
6. **Privacy**: Visit `/settings` to control visibility
7. **Admin**: Login with an admin account, visit `/admin`

## Security Notes

- **Never expose the `SUPABASE_SERVICE_ROLE_KEY`** in frontend code
- Enable email verification in Supabase dashboard
- Configure rate limiting in Supabase (built-in)
- Keep dependencies updated
- Use HTTPS in production
- The `.env` file contains secrets — never commit it

## Limitations & Future Work

- Push notifications require a server-side worker or Supabase Edge Functions
- Avatar uploads need Supabase Storage configuration
- Email verification and password reset need Supabase Auth configuration
- OAuth providers need to be enabled in Supabase dashboard
- Rate limiting can be enhanced with Supabase Edge Functions
- Message read receipts are tracked but not all displayed in UI

## License

Private - All rights reserved.

---

Built with ❤️ for genuine human connections.