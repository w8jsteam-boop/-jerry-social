import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ProfileCardSkeleton } from '../components/UI/Skeleton';
import toast from 'react-hot-toast';

interface DiscoverProfile {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  interests: string[];
  language: string;
  last_active: string | null;
  friendship_status?: string | null;
}

const INTEREST_OPTIONS = [
  'Art', 'Music', 'Technology', 'Travel', 'Fitness', 'Reading',
  'Gaming', 'Cooking', 'Photography', 'Nature', 'Sports', 'Movies',
  'Science', 'Fashion', 'Dancing', 'Writing', 'Coding', 'Design'
];

const LANGUAGE_OPTIONS = [
  'English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese',
  'Japanese', 'Korean', 'Chinese', 'Arabic', 'Hindi', 'Russian'
];

export default function Discover() {
  const { user, profile } = useAuth();
  const [profiles, setProfiles] = useState<DiscoverProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [sendingRequest, setSendingRequest] = useState<string | null>(null);

  const fetchProfiles = useCallback(async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      let query = supabase
        .from('profiles')
        .select(`
          id, username, display_name, avatar_url, bio, interests, language, last_active
        `)
        .neq('id', user.id)
        .eq('age_verified', true)
        .eq('is_suspended', false)
        .in('visibility', ['public', 'connections'])
        .limit(50);

      if (searchTerm) {
        query = query.or(`username.ilike.%${searchTerm}%,display_name.ilike.%${searchTerm}%`);
      }

      if (selectedInterests.length > 0) {
        query = query.contains('interests', selectedInterests);
      }

      if (selectedLanguage) {
        query = query.eq('language', selectedLanguage);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Get friendship statuses
      const profileIds = (data || []).map(p => p.id);
      
      const { data: friendships } = await supabase
        .from('friendship_requests')
        .select('*')
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .in('sender_id', profileIds)
        .in('receiver_id', profileIds);

      const profilesWithStatus = (data || []).map(p => {
        const friendship = friendships?.find(
          f => (f.sender_id === user.id && f.receiver_id === p.id) ||
               (f.receiver_id === user.id && f.sender_id === p.id)
        );
        return {
          ...p,
          interests: p.interests || [],
          friendship_status: friendship?.status || null,
        };
      });

      setProfiles(profilesWithStatus as DiscoverProfile[]);
    } catch (error: any) {
      console.error('Error fetching profiles:', error);
      toast.error('Failed to load profiles');
    } finally {
      setLoading(false);
    }
  }, [user, searchTerm, selectedInterests, selectedLanguage]);

  useEffect(() => {
    fetchProfiles();
  }, [fetchProfiles]);

  const sendFriendRequest = async (receiverId: string) => {
    if (!user) return;
    setSendingRequest(receiverId);

    try {
      const { error } = await supabase
        .from('friendship_requests')
        .insert({
          sender_id: user.id,
          receiver_id: receiverId,
          status: 'pending',
        });

      if (error) {
        if (error.code === '23505') {
          toast.error('Request already sent');
        } else {
          throw error;
        }
      } else {
        toast.success('Friend request sent!');
        fetchProfiles();
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to send request');
    } finally {
      setSendingRequest(null);
    }
  };

  const toggleInterest = (interest: string) => {
    setSelectedInterests(prev =>
      prev.includes(interest)
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  return (
    <div className="page-container">
      <div className="content-container">
        <div className="mb-6">
          <h1 className="section-title">Discover People</h1>
          <p className="text-jerry-200/60 text-sm">
            Find people with shared interests and make new connections
          </p>
        </div>

        {/* Search & Filters */}
        <div className="glass-card p-4 mb-6 space-y-4">
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-jerry-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search by name or username..."
              className="input-field pl-10"
            />
          </div>

          {/* Interests Filter */}
          <div>
            <label className="text-sm text-jerry-200/70 mb-2 block">Filter by interests</label>
            <div className="flex flex-wrap gap-2">
              {INTEREST_OPTIONS.map(interest => (
                <button
                  key={interest}
                  onClick={() => toggleInterest(interest)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                    selectedInterests.includes(interest)
                      ? 'bg-jerry-500/30 text-jerry-200 border border-jerry-400/50'
                      : 'bg-jerry-900/30 text-jerry-300/60 border border-jerry-800/30 hover:bg-jerry-800/30'
                  }`}
                >
                  {interest}
                </button>
              ))}
            </div>
          </div>

          {/* Language Filter */}
          <div>
            <label className="text-sm text-jerry-200/70 mb-2 block">Language</label>
            <select
              value={selectedLanguage}
              onChange={e => setSelectedLanguage(e.target.value)}
              className="input-field"
            >
              <option value="">All languages</option>
              {LANGUAGE_OPTIONS.map(lang => (
                <option key={lang} value={lang}>{lang}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Profiles Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => <ProfileCardSkeleton key={i} />)}
          </div>
        ) : profiles.length === 0 ? (
          <div className="glass-card p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-jerry-500/20 flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No profiles found</h3>
            <p className="text-jerry-200/60 text-sm">
              Try adjusting your filters or search terms to find more people.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {profiles.map(p => (
              <div key={p.id} className="glass-card-hover p-4 animate-in">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-jerry-400 to-jerry-600 flex items-center justify-center text-xl font-bold shrink-0">
                    {p.avatar_url ? (
                      <img src={p.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      (p.display_name || p.username || '?').charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white truncate">
                      {p.display_name || p.username || 'Anonymous'}
                    </h3>
                    {p.display_name && p.username && (
                      <p className="text-jerry-400 text-xs truncate">@{p.username}</p>
                    )}
                    {p.bio && (
                      <p className="text-jerry-200/60 text-sm mt-1 line-clamp-2">{p.bio}</p>
                    )}
                  </div>
                </div>

                {p.interests && p.interests.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {p.interests.slice(0, 5).map(interest => (
                      <span key={interest} className="badge-primary text-[10px]">{interest}</span>
                    ))}
                    {p.interests.length > 5 && (
                      <span className="text-jerry-400 text-[10px]">+{p.interests.length - 5}</span>
                    )}
                  </div>
                )}

                <div className="mt-3 flex items-center justify-between">
                  {p.language && (
                    <span className="text-jerry-400 text-xs">{p.language}</span>
                  )}
                  <span className="text-jerry-400 text-xs">
                    {p.last_active ? (
                      new Date(p.last_active).toLocaleDateString()
                    ) : 'New'}
                  </span>
                </div>

                <div className="mt-3">
                  {p.friendship_status === 'accepted' ? (
                    <span className="badge-success w-full justify-center py-2">Connected</span>
                  ) : p.friendship_status === 'pending' ? (
                    <span className="badge-warning w-full justify-center py-2">Request Pending</span>
                  ) : p.friendship_status === 'declined' ? (
                    <span className="badge-danger w-full justify-center py-2">Request Declined</span>
                  ) : (
                    <button
                      onClick={() => sendFriendRequest(p.id)}
                      disabled={sendingRequest === p.id}
                      className="btn-primary w-full text-sm py-2"
                    >
                      {sendingRequest === p.id ? 'Sending...' : 'Connect'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}