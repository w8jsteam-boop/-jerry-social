import React from 'react';
import { Link } from 'react-router-dom';

interface InfoPageProps {
  title: string;
  subtitle?: string;
  lastUpdated?: string;
  children: React.ReactNode;
}

export function InfoPage({ title, subtitle, lastUpdated, children }: InfoPageProps) {
  return (
    <div className="min-h-screen bg-[#0d0229]">
      <div className="max-w-3xl mx-auto px-4 py-12">
        <Link to="/" className="inline-flex items-center gap-2 text-jerry-300 hover:text-white mb-8 transition-colors">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to JERRY
        </Link>

        <div className="glass-card p-8 md:p-12">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">{title}</h1>
          {subtitle && <p className="text-jerry-200/70 text-lg mb-6">{subtitle}</p>}
          {lastUpdated && (
            <p className="text-jerry-400 text-sm mb-8">Last updated: {lastUpdated}</p>
          )}
          <div className="prose prose-invert max-w-none">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

export function About() {
  return (
    <InfoPage title="About JERRY" subtitle="Building authentic connections in a private, secure space.">
      <h2>Our Mission</h2>
      <p>
        JERRY is a private social connection platform designed for adults aged 18 and older. 
        Our mission is to create a space where meaningful connections can flourish without 
        the noise, data exploitation, and privacy concerns of traditional social media.
      </p>

      <h2>Why JERRY?</h2>
      <p>
        Unlike mainstream social platforms that monetize your attention and data, JERRY is built 
        on principles of privacy, consent, and genuine connection. We believe that social platforms 
        should empower users, not exploit them.
      </p>

      <h2>Our Values</h2>
      <ul>
        <li><strong>Privacy First:</strong> Your data belongs to you. We never share or sell personal information.</li>
        <li><strong>Consent is Key:</strong> Two-way friendships and messaging ensure mutual interest.</li>
        <li><strong>Safety by Design:</strong> Age verification, reporting tools, and active moderation protect our community.</li>
        <li><strong>Transparency:</strong> Clear policies and open communication about how the platform operates.</li>
      </ul>

      <h2>Not Affiliated with Tom and Jerry</h2>
      <p>
        JERRY is an independent platform and is not affiliated with, endorsed by, or connected to 
        the Tom and Jerry cartoon franchise or its copyright holders. Our name and original mouse-inspired 
        logo are used as a friendly identifier for our community.
      </p>
    </InfoPage>
  );
}

export function Privacy() {
  return (
    <InfoPage title="Privacy Policy" lastUpdated="January 1, 2024">
      <h2>Information We Collect</h2>
      <p>
        We collect only the information necessary to provide our service:
      </p>
      <ul>
        <li>Account information (email address, username, password hash)</li>
        <li>Age verification data (date of birth, stored securely and never shared)</li>
        <li>Profile information you choose to provide (display name, bio, interests)</li>
        <li>Communications data (messages between connected users)</li>
      </ul>

      <h2>How We Use Your Information</h2>
      <ul>
        <li>To provide and maintain the JERRY platform</li>
        <li>To verify age eligibility (18+)</li>
        <li>To facilitate connections and messaging between users</li>
        <li>To moderate content and enforce community guidelines</li>
      </ul>

      <h2>Data Protection</h2>
      <p>
        We implement industry-standard security measures including encryption in transit and at rest, 
        secure session management, and regular security audits. Your private messages are only accessible 
        to conversation participants.
      </p>

      <h2>Your Rights</h2>
      <ul>
        <li>Access and export your data at any time</li>
        <li>Delete your account and associated data</li>
        <li>Control profile visibility and discoverability</li>
        <li>Block and report other users</li>
      </ul>

      <h2>Contact</h2>
      <p>
        For privacy-related inquiries, contact our Data Protection Officer at{' '}
        <a href="mailto:privacy@jerry.app">privacy@jerry.app</a>.
      </p>
    </InfoPage>
  );
}

export function Terms() {
  return (
    <InfoPage title="Terms of Service" lastUpdated="January 1, 2024">
      <h2>Acceptance of Terms</h2>
      <p>
        By using JERRY, you agree to these Terms of Service. If you do not agree, do not use the platform.
      </p>

      <h2>Eligibility</h2>
      <p>
        You must be at least 18 years old to use JERRY. By creating an account, you confirm that you 
        meet this age requirement and that the age verification information you provide is accurate.
      </p>

      <h2>User Responsibilities</h2>
      <ul>
        <li>Provide accurate information during registration</li>
        <li>Maintain the confidentiality of your account credentials</li>
        <li>Respect other users and follow community guidelines</li>
        <li>Not engage in harassment, spam, or abusive behavior</li>
        <li>Not attempt to circumvent safety features or moderation</li>
      </ul>

      <h2>Prohibited Content</h2>
      <ul>
        <li>Illegal content or activity</li>
        <li>Harassment, hate speech, or threats</li>
        <li>Nudity, sexual content, or explicit material</li>
        <li>Spam, scams, or misleading information</li>
        <li>Content that violates others' intellectual property</li>
      </ul>

      <h2>Account Termination</h2>
      <p>
        We reserve the right to suspend or terminate accounts that violate these terms. Users may 
        delete their own accounts at any time through account settings.
      </p>
    </InfoPage>
  );
}

export function Guidelines() {
  return (
    <InfoPage title="Community Guidelines" lastUpdated="January 1, 2024">
      <h2>Be Respectful</h2>
      <p>
        Treat others with kindness and respect. Harassment, discrimination, and hate speech 
        will not be tolerated.
      </p>

      <h2>Consent Matters</h2>
      <p>
        Only send friend requests and messages to users who have indicated they are open to 
        connection. Respect when someone declines a request or blocks you.
      </p>

      <h2>Be Authentic</h2>
      <p>
        Use your real identity. Impersonation, catfishing, and deceptive practices are prohibited.
      </p>

      <h2>Keep It Safe</h2>
      <p>
        Do not share personal contact information (phone, address, financial details) publicly. 
        Report suspicious behavior to moderators.
      </p>

      <h2>No Spam</h2>
      <p>
        Do not send unsolicited promotional content, chain messages, or repetitive messages.
      </p>

      <h2>Reporting Violations</h2>
      <p>
        If you see content or behavior that violates these guidelines, use the report feature 
        or contact our moderation team. All reports are reviewed promptly.
      </p>
    </InfoPage>
  );
}

export function Contact() {
  return (
    <InfoPage title="Contact & Support" subtitle="We're here to help">
      <h2>Get in Touch</h2>
      <p>
        Have questions, concerns, or feedback? Reach out to us through any of these channels:
      </p>

      <div className="glass-card p-6 my-6 space-y-4">
        <div>
          <h3 className="text-jerry-200 font-medium mb-1">Email Support</h3>
          <a href="mailto:support@jerry.app" className="text-jerry-300 hover:text-white">support@jerry.app</a>
        </div>
        <div>
          <h3 className="text-jerry-200 font-medium mb-1">Report Abuse</h3>
          <a href="mailto:abuse@jerry.app" className="text-jerry-300 hover:text-white">abuse@jerry.app</a>
        </div>
        <div>
          <h3 className="text-jerry-200 font-medium mb-1">Privacy Inquiries</h3>
          <a href="mailto:privacy@jerry.app" className="text-jerry-300 hover:text-white">privacy@jerry.app</a>
        </div>
      </div>

      <h2>Response Times</h2>
      <ul>
        <li>General inquiries: within 24 hours</li>
        <li>Abuse reports: within 12 hours</li>
        <li>Privacy requests: within 48 hours</li>
        <li>Emergency issues: immediate attention</li>
      </ul>

      <h2>Report a Problem</h2>
      <p>
        To report a user, message, or content that violates our guidelines, use the report 
        feature throughout the app or email our moderation team directly.
      </p>
    </InfoPage>
  );
}