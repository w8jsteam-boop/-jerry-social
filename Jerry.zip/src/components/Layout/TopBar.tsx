import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';

export default function TopBar() {
  const { isAuthenticated, profile } = useAuth();
  const { isDark, toggle } = useTheme();
  const location = useLocation();

  if (!isAuthenticated) return null;

  const isLanding = location.pathname === '/';

  return (
    <header className="fixed top-0 left-0 right-0 z-50 hidden md:block">
      <div className="glass border-b border-glass-heavy">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-jerry-500 to-jerry-700 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
            </div>
            <span className="font-display font-bold text-lg text-white">JERRY</span>
          </Link>

          <nav className="flex items-center gap-6">
            <Link to="/discover" className="text-jerry-200 hover:text-white transition-colors text-sm font-medium">
              Discover
            </Link>
            <Link to="/connections" className="text-jerry-200 hover:text-white transition-colors text-sm font-medium">
              Connections
            </Link>
            <Link to="/messages" className="text-jerry-200 hover:text-white transition-colors text-sm font-medium">
              Messages
            </Link>
            <Link to="/notifications" className="text-jerry-200 hover:text-white transition-colors text-sm font-medium">
              Notifications
            </Link>

            <button
              onClick={toggle}
              className="p-2 rounded-lg hover:bg-glass-medium transition-colors"
              aria-label="Toggle theme"
            >
              {isDark ? (
                <svg className="w-5 h-5 text-jerry-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              ) : (
                <svg className="w-5 h-5 text-jerry-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>
              )}
            </button>

            <Link
              to="/profile"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-glass-medium transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-jerry-400 to-jerry-600 flex items-center justify-center text-sm font-bold">
                {profile?.display_name?.charAt(0) || profile?.username?.charAt(0) || '?'}
              </div>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}