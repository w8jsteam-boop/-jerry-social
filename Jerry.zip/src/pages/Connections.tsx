import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ProfileCardSkeleton } from '../components/UI/Skeleton';
import toast from 'react-hot-toast';

interface ConnectionProfile {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  interests: string[];
  last_active: string | null;
}

interface RequestProfile extends ConnectionProfile {
  request_id: string;
  sender_id: string;
  status: string;
  created_at: string;
}

type Tab = 'connections' | 'received' | 'sent';

export default function Connections() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('connections');
  const [connections, setConnections] = useState<ConnectionProfile[]>([]);
  const [receivedRequests, setReceivedRequests] = useState<RequestProfile[]>([]);
  const [sentRequests, setSentRequests] = useState<RequestProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    try {
      // Fetch accepted connections
      const { data: acceptedData, error: acceptedError } = await supabase
        .from('friendship_requests')
        .select(`
          id, sender_id, receiver_id, status, created_at,
          sender:profiles!friendship_requests_sender_id_fkey(id, username, display_name, avatar_url, bio, interests, last_active),
          receiver:profiles!friendship_requests_receiver_id_fkey(id, username, display_name, avatar_url, bio, interests, last_active)
        `)
        .eq('status', 'accepted')
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`);

      if (acceptedError) throw acceptedError;

      const connectionsList = (acceptedData || []).map(req => {
        const profile = req.sender_id === user.id ? req.receiver : req.sender;
        return profile ? {
          id: profile.id,
          username: profile.username,
          display_name: profile.display_name,
          avatar_url: profile.avatar_url,
          bio: profile.bio,
          interests: profile.interests || [],
          last_active: profile.last_active,
        } : null;
      }).filter(Boolean) as ConnectionProfile[];

      setConnections(connectionsList);

      // Fetch received pending requests
      const { data: receivedData, error: receivedError } = await supabase
        .from('friendship_requests')
        .select(`
          id, sender_id, receiver_id, status, created_at,
          sender:profiles!friendship_requests_sender_id_fkey(id, username, display_name, avatar_url, bio, interests, last_active)
        `)
        .eq('receiver_id', user.id)
        .eq('status', 'pending');

      if (receivedError) throw receivedError;

      setReceivedRequests((receivedData || []).map(req => ({
        id: req.sender?.id || '',
        username: req.sender?.username || null,
        display_name: req.sender?.display_name || null,
        avatar_url: req.sender?.avatar_url || null,
        bio: req.sender?.bio || null,
        interests: req.sender?.interests || [],
        last_active: req.sender?.last_active || null,
        request_id: req.id,
        sender_id: req.sender_id,
        status: req.status,
        created_at: req.created_at,
      })));

      // Fetch sent pending requests
      const { data: sentData, error: sentError } = await supabase
        .from('friendship_requests')
        .select(`
          id, sender_id, receiver_id, status, created_at,
          receiver:profiles!friendship_requests_receiver_id_fkey(id, username, display_name, avatar_url, bio, interests, last_active)
        `)
        .eq('sender_id', user.id)
        .eq('status', 'pending');

      if (sentError) throw sentError;

      setSentRequests((sentData || []).map(req => ({
        id: req.receiver?.id || '',
        username: req.receiver?.username || null,
        display_name: req.receiver?.display_name || null,
        avatar_url: req.receiver?.avatar_url || null,
        bio: req.receiver?.bio || null,
        interests: req.receiver?.interests || [],
        last_active: req.receiver?.last_active || null,
        request_id: req.id,
        sender_id: req.sender_id,
        status: req.status,
        created_at: req.created_at,
      })));
    } catch (error: any) {
      console.error('Error fetching connections:', error);
      toast.error('Failed to load connections');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleRequest = async (requestId: string, action: 'accepted' | 'declined') => {
    setProcessingId(requestId);
    try {
      const { error } = await supabase
        .from('friendship_requests')
        .update({ status: action, updated_at: new Date().toISOString() })
        .eq('id', requestId);

      if (error) throw error;

      toast.success(action === 'accepted' ? 'Connection accepted!' : 'Request declined');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update request');
    } finally {
      setProcessingId(null);
    }
  };

  const removeConnection = async (profileId: string) => {
    if (!user) return;
    setProcessingId(profileId);

    try {
      const { error } = await supabase
        .from('friendship_requests')
        .update({ status: 'declined', updated_at: new Date().toISOString() })
        .eq('status', 'accepted')
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${profileId}),and(sender_id.eq.${profileId},receiver_id.eq.${user.id})`);

      if (error) throw error;

      toast.success('Connection removed');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to remove connection');
    } finally {
      setProcessingId(null);
    }
  };

  const cancelRequest = async (requestId: string) => {
    setProcessingId(requestId);
    try {
      const { error } = await supabase
        .from('friendship_requests')
        .delete()
        .eq('id', requestId);

      if (error) throw error;

      toast.success('Request cancelled');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to cancel request');
    } finally {
      setProcessingId(null);
    }
  };

  const tabs: { key: Tab; label: string; count?: number }[] = [
    { key: 'connections', label: 'Connections', count: connections.length },
    { key: 'received', label: 'Received', count: receivedRequests.length },
    { key: 'sent', label: 'Sent', count: sentRequests.length },
  ];

  const ProfileCard = ({ profile, actions }: { profile: ConnectionProfile | RequestProfile; actions: React.ReactNode }) => (
    <div className="glass-card-hover p-4 animate-in">
      <div className="flex items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-jerry-400 to-jerry-600 flex items-center justify-center text-xl font-bold shrink-0">
          {profile.avatar_url ? (
            <img src={profile.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
          ) : (
            (profile.display_name || profile.username || '?').charAt(0).toUpperCase()
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-white truncate">
            {profile.display_name || profile.username || 'Anonymous'}
          </h3>
          {profile.bio && (
            <p className="text-jerry-200/60 text-sm truncate">{profile.bio}</p>
          )}
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <div className="flex gap-1.5 flex-wrap">
          {(profile.interests || []).slice(0, 3).map(i => (
            <span key={i} className="badge-primary text-[10px]">{i}</span>
          ))}
        </div>
      </div>
      <div className="mt-3 flex gap-2">
        {actions}
      </div>
    </div>
  );

  return (
    <div className="page-container">
      <div className="content-container">
        <h1 className="section-title">Connections</h1>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 glass-card p-1">
          {tabs.map(({ key, label, count }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-all duration-200 ${
                activeTab === key
                  ? 'bg-jerry-500/20 text-jerry-200 shadow-sm'
                  : 'text-jerry-400 hover:text-jerry-300'
              }`}
            >
              {label}
              {count !== undefined && count > 0 && (
                <span className={`ml-2 px-1.5 py-0.5 rounded-full text-xs ${
                  activeTab === key ? 'bg-jerry-500/30' : 'bg-jerry-900/50'
                }`}>
                  {count}
                </span>
              )}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => <ProfileCardSkeleton key={i} />)}
          </div>
        ) : activeTab === 'connections' ? (
          connections.length === 0 ? (
            <div className="glass-card p-12 text-center">
              <p className="text-jerry-200/60">No connections yet. Discover people to connect with!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {connections.map(c => (
                <ProfileCard
                  key={c.id}
                  profile={c}
                  actions={
                    <button
                      onClick={() => removeConnection(c.id)}
                      disabled={processingId === c.id}
                      className="btn-danger text-sm py-1.5 px-3 flex-1"
                    >
                      {processingId === c.id ? '...' : 'Remove'}
                    </button>
                  }
                />
              ))}
            </div>
          )
        ) : activeTab === 'received' ? (
          receivedRequests.length === 0 ? (
            <div className="glass-card p-12 text-center">
              <p className="text-jerry-200/60">No pending friend requests</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {receivedRequests.map(r => (
                <ProfileCard
                  key={r.request_id}
                  profile={r}
                  actions={
                    <>
                      <button
                        onClick={() => handleRequest(r.request_id, 'accepted')}
                        disabled={processingId === r.request_id}
                        className="btn-primary text-sm py-1.5 px-3 flex-1"
                      >
                        {processingId === r.request_id ? '...' : 'Accept'}
                      </button>
                      <button
                        onClick={() => handleRequest(r.request_id, 'declined')}
                        disabled={processingId === r.request_id}
                        className="btn-secondary text-sm py-1.5 px-3 flex-1"
                      >
                        Decline
                      </button>
                    </>
                  }
                />
              ))}
            </div>
          )
        ) : (
          sentRequests.length === 0 ? (
            <div className="glass-card p-12 text-center">
              <p className="text-jerry-200/60">No pending sent requests</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sentRequests.map(r => (
                <ProfileCard
                  key={r.request_id}
                  profile={r}
                  actions={
                    <button
                      onClick={() => cancelRequest(r.request_id)}
                      disabled={processingId === r.request_id}
                      className="btn-danger text-sm py-1.5 px-3 flex-1"
                    >
                      {processingId === r.request_id ? '...' : 'Cancel'}
                    </button>
                  }
                />
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}