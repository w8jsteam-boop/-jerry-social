import React from 'react';
import { Outlet } from 'react-router-dom';
import BottomNav from './BottomNav';
import TopBar from './TopBar';

export default function AppShell() {
  return (
    <div className="min-h-screen bg-[#0d0229]">
      <TopBar />
      <main className="pb-20 md:pb-0 md:pt-16">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}