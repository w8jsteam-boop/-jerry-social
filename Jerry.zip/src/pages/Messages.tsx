import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ConversationListSkeleton, MessageSkeleton } from '../components/UI/Skeleton';
import toast from 'react-hot-toast';

interface Conversation {
  id: string;
  created_at: string;
  last_message_at: string | null;
  last_message_preview: string | null;
  other_user: {
    id: string;
    username: string | null;
    display_name: string | null;
    avatar_url: string | null;
  };
  unread_count: number;
}

interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  type: 'text' | 'image' | 'system';
  read_at: string | null;
  created_at: string;
}

const MESSAGES_PER_PAGE = 30;

export default function Messages() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [showMobileList, setShowMobileList] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messageInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchConversations = useCallback(async () => {
    if (!user) return;
    setLoadingConversations(true);

    try {
      const { data: memberData, error: memberError } = await supabase
        .from('conversation_members')
        .select(`
          conversation_id,
          conversations!inner(id, created_at, last_message_at, last_message_preview)
        `)
        .eq('user_id', user.id);

      if (memberError) throw memberError;

      const conversationIds = (memberData || []).map(m => m.conversation_id);

      if (conversationIds.length === 0) {
        setConversations([]);
        setLoadingConversations(false);
        return;
      }

      // Fetch other members for each conversation
      const { data: otherMembers, error: otherError } = await supabase
        .from('conversation_members')
        .select(`
          conversation_id,
          user_id,
          profiles:user_id(id, username, display_name, avatar_url)
        `)
        .in('conversation_id', conversationIds)
        .neq('user_id', user.id);

      if (otherError) throw otherError;

      // Fetch unread counts
      const { data: unreadData } = await supabase
        .from('conversation_members')
        .select('conversation_id, last_read_at')
        .eq('user_id', user.id)
        .in('conversation_id', conversationIds);

      const convMap = new Map();
      (memberData || []).forEach(m => {
        const conv = m.conversations;
        const other = (otherMembers || []).find(om => om.conversation_id === m.conversation_id);
        const unread = (unreadData || []).find(u => u.conversation_id === m.conversation_id);
        
        convMap.set(m.conversation_id, {
          id: m.conversation_id,
          created_at: conv.created_at,
          last_message_at: conv.last_message_at,
          last_message_preview: conv.last_message_preview,
          other_user: other?.profiles ? {
            id: other.profiles.id,
            username: other.profiles.username,
            display_name: other.profiles.display_name,
            avatar_url: other.profiles.avatar_url,
          } : { id: '', username: 'Unknown', display_name: null, avatar_url: null },
          unread_count: 0, // Simplified; you'd count messages after last_read_at
        });
      });

      setConversations(Array.from(convMap.values()));
    } catch (error: any) {
      console.error('Error fetching conversations:', error);
      toast.error('Failed to load conversations');
    } finally {
      setLoadingConversations(false);
    }
  }, [user]);

  const fetchMessages = useCallback(async (conversationId: string) => {
    setLoadingMessages(true);
    setMessages([]);

    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true })
        .limit(MESSAGES_PER_PAGE);

      if (error) throw error;

      setMessages(data || []);

      // Update last_read_at
      if (user) {
        await supabase
          .from('conversation_members')
          .update({ last_read_at: new Date().toISOString() })
          .eq('conversation_id', conversationId)
          .eq('user_id', user.id);
      }
    } catch (error: any) {
      console.error('Error fetching messages:', error);
      toast.error('Failed to load messages');
    } finally {
      setLoadingMessages(false);
    }
  }, [user]);

  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation);
      setShowMobileList(false);
    }
  }, [selectedConversation, fetchMessages]);

  // Real-time subscription
  useEffect(() => {
    if (!selectedConversation) return;

    const channel = supabase
      .channel(`messages:${selectedConversation}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${selectedConversation}`,
        },
        (payload) => {
          const newMsg = payload.new as Message;
          setMessages(prev => [...prev, newMsg]);
          fetchConversations(); // Update preview
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedConversation, fetchConversations]);

  const sendMessage = async () => {
    if (!user || !selectedConversation || !newMessage.trim() || sendingMessage) return;

    const content = newMessage.trim();
    if (content.length > 5000) {
      toast.error('Message too long (max 5000 characters)');
      return;
    }

    setSendingMessage(true);
    try {
      const { error } = await supabase
        .from('messages')
        .insert({
          conversation_id: selectedConversation,
          sender_id: user.id,
          content,
          type: 'text',
        });

      if (error) throw error;

      // Update conversation's last message
      await supabase
        .from('conversations')
        .update({
          last_message_at: new Date().toISOString(),
          last_message_preview: content.substring(0, 100),
        })
        .eq('id', selectedConversation);

      setNewMessage('');
      messageInputRef.current?.focus();
    } catch (error: any) {
      toast.error(error.message || 'Failed to send message');
    } finally {
      setSendingMessage(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (days === 1) {
      return 'Yesterday';
    } else if (days < 7) {
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const startNewConversation = async () => {
    // Navigate to discover to find someone
    toast('Go to Discover to find new connections first');
  };

  const selectConversation = (convId: string) => {
    setSelectedConversation(convId);
    if (window.innerWidth < 768) {
      setShowMobileList(false);
    }
  };

  return (
    <div className="page-container">
      <div className="h-[calc(100vh-8rem)] md:h-[calc(100vh-4rem)] flex">
        {/* Conversation List */}
        <div className={`${
          showMobileList || window.innerWidth >= 768 ? 'block' : 'hidden'
        } md:block w-full md:w-80 lg:w-96 border-r border-glass-heavy flex flex-col`}>
          <div className="p-4 border-b border-glass-heavy">
            <h2 className="text-lg font-semibold text-white">Messages</h2>
          </div>

          <div className="flex-1 overflow-y-auto scrollbar-thin">
            {loadingConversations ? (
              <ConversationListSkeleton />
            ) : conversations.length === 0 ? (
              <div className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-jerry-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </div>
                <p className="text-jerry-200/60 text-sm">No conversations yet</p>
                <p className="text-jerry-400/60 text-xs mt-1">Connect with someone to start chatting</p>
              </div>
            ) : (
              conversations.map(conv => (
                <button
                  key={conv.id}
                  onClick={() => selectConversation(conv.id)}
                  className={`w-full p-4 flex items-center gap-3 transition-colors hover:bg-glass-medium ${
                    selectedConversation === conv.id ? 'bg-jerry-500/10' : ''
                  }`}
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-jerry-400 to-jerry-600 flex items-center justify-center text-lg font-bold shrink-0">
                    {conv.other_user.avatar_url ? (
                      <img src={conv.other_user.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      (conv.other_user.display_name || conv.other_user.username || '?').charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium text-white text-sm truncate">
                        {conv.other_user.display_name || conv.other_user.username || 'Unknown'}
                      </h3>
                      {conv.last_message_at && (
                        <span className="text-jerry-400 text-xs ml-2 shrink-0">
                          {formatTime(conv.last_message_at)}
                        </span>
                      )}
                    </div>
                    <p className="text-jerry-400 text-sm truncate mt-0.5">
                      {conv.last_message_preview || 'No messages yet'}
                    </p>
                  </div>
                  {conv.unread_count > 0 && (
                    <span className="w-5 h-5 rounded-full bg-jerry-500 text-white text-xs flex items-center justify-center shrink-0">
                      {conv.unread_count}
                    </span>
                  )}
                </button>
              ))
            )}
          </div>

          <div className="p-4 border-t border-glass-heavy">
            <button onClick={startNewConversation} className="btn-primary w-full text-sm py-2.5">
              New Message
            </button>
          </div>
        </div>

        {/* Chat Area */}
        <div className={`${
          !showMobileList || window.innerWidth >= 768 ? 'flex' : 'hidden'
        } md:flex flex-1 flex-col`}>
          {selectedConversation ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-glass-heavy flex items-center gap-3">
                <button
                  onClick={() => setShowMobileList(true)}
                  className="md:hidden p-1 -ml-1 text-jerry-300 hover:text-white"
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-jerry-400 to-jerry-600 flex items-center justify-center font-bold shrink-0">
                  {conversations.find(c => c.id === selectedConversation)?.other_user.display_name?.charAt(0) || '?'}
                </div>
                <div>
                  <h3 className="font-medium text-white text-sm">
                    {conversations.find(c => c.id === selectedConversation)?.other_user.display_name || 'User'}
                  </h3>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
                {loadingMessages ? (
                  <MessageSkeleton />
                ) : messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-jerry-400/60 text-sm">No messages yet. Say hello!</p>
                  </div>
                ) : (
                  messages.map(msg => {
                    const isMine = msg.sender_id === user?.id;
                    return (
                      <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'} animate-in`}>
                        <div className={`max-w-[80%] ${
                          isMine
                            ? 'bg-jerry-500/20 border border-jerry-500/30'
                            : 'bg-white/5 border border-jerry-400/10'
                        } rounded-2xl px-4 py-2.5`}>
                          {msg.type === 'system' ? (
                            <p className="text-jerry-400 text-xs text-center italic">{msg.content}</p>
                          ) : (
                            <>
                              <p className="text-white/90 text-sm whitespace-pre-wrap break-words">{msg.content}</p>
                              <p className="text-jerry-400 text-[10px] mt-1 text-right">
                                {formatTime(msg.created_at)}
                                {isMine && msg.read_at && (
                                  <span className="ml-1 text-green-400">✓✓</span>
                                )}
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <div className="p-4 border-t border-glass-heavy">
                <div className="flex gap-2">
                  <input
                    ref={messageInputRef}
                    type="text"
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type a message..."
                    className="input-field flex-1"
                    maxLength={5000}
                    disabled={sendingMessage}
                    autoFocus
                  />
                  <button
                    onClick={sendMessage}
                    disabled={!newMessage.trim() || sendingMessage}
                    className="btn-primary px-4"
                  >
                    {sendingMessage ? (
                      <svg className="w-5 h-5 animate-spin" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 19V5m0 0l-7 7m7-7l7 7" />
                      </svg>
                    )}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-jerry-500/10 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-10 h-10 text-jerry-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Your Messages</h3>
                <p className="text-jerry-200/60 text-sm max-w-sm">
                  Select a conversation or start a new one by connecting with someone on Discover.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}