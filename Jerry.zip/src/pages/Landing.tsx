import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Landing() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-[#0d0229]">
      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-jerry-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-jerry-400/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-jerry-600/5 rounded-full blur-3xl" />
        </div>

        {/* Navigation */}
        <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-glass-heavy">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-jerry-500 to-jerry-700 flex items-center justify-center shadow-lg shadow-jerry-500/30">
                <svg viewBox="0 0 24 24" className="w-6 h-6 text-white" fill="currentColor">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                </svg>
              </div>
              <span className="font-display font-bold text-xl text-white">JERRY</span>
            </div>
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <Link to="/discover" className="btn-primary text-sm px-4 py-2">
                  Dashboard
                </Link>
              ) : (
                <>
                  <Link to="/login" className="btn-secondary text-sm px-4 py-2">
                    Sign In
                  </Link>
                  <Link to="/signup" className="btn-primary text-sm px-4 py-2">
                    Join JERRY
                  </Link>
                </>
              )}
            </div>
          </div>
        </nav>

        {/* Hero Content */}
        <div className="relative z-10 text-center max-w-3xl mx-auto mt-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-jerry-500/10 border border-jerry-500/20 text-jerry-200 text-sm mb-8 animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            Private & Secure Connection Platform
          </div>

          <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6 leading-tight animate-slide-up">
            Connect
            <span className="text-gradient"> Authentically</span>
            <br />
            Stay Private
          </h1>

          <p className="text-lg md:text-xl text-jerry-200/80 mb-10 max-w-2xl mx-auto animate-fade-in">
            JERRY is a private social connection platform for adults 18+. 
            Create meaningful connections with mutual consent, real-time chat, 
            and complete control over your privacy.
          </p>

          {!isAuthenticated && (
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Link to="/signup" className="btn-primary text-lg px-8 py-4">
                Create Your Profile
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
              <Link to="/about" className="btn-secondary text-lg px-8 py-4">
                Learn More
              </Link>
            </div>
          )}
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 animate-bounce">
          <svg className="w-6 h-6 text-jerry-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 relative">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-center mb-16">
            Built for <span className="text-gradient">Real Connections</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className="glass-card p-6 hover:bg-glass-medium transition-all duration-300 group animate-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-xl bg-jerry-500/20 flex items-center justify-center mb-4 group-hover:bg-jerry-500/30 transition-colors">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-jerry-200/70 text-sm leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Privacy Section */}
      <section className="py-20 px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="glass-card p-8 md:p-12">
            <h2 className="text-3xl font-display font-bold mb-6">
              Your Privacy is <span className="text-gradient">Sacred</span>
            </h2>
            <p className="text-jerry-200/80 mb-8 leading-relaxed">
              JERRY is designed with privacy-first principles. We never share your data, 
              never expose your personal information, and give you full control over who 
              can see your profile and contact you. All messages are private between 
              connected users.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              {privacyFeatures.map((item, i) => (
                <span key={i} className="badge-primary px-4 py-2 text-sm">{item}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-glass-heavy py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold text-white mb-4">Platform</h4>
              <ul className="space-y-2">
                <li><Link to="/about" className="text-jerry-300 hover:text-white text-sm transition-colors">About</Link></li>
                <li><Link to="/guidelines" className="text-jerry-300 hover:text-white text-sm transition-colors">Guidelines</Link></li>
                <li><Link to="/contact" className="text-jerry-300 hover:text-white text-sm transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2">
                <li><Link to="/privacy" className="text-jerry-300 hover:text-white text-sm transition-colors">Privacy</Link></li>
                <li><Link to="/terms" className="text-jerry-300 hover:text-white text-sm transition-colors">Terms</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Safety</h4>
              <ul className="space-y-2">
                <li><Link to="/guidelines" className="text-jerry-300 hover:text-white text-sm transition-colors">Community Guidelines</Link></li>
                <li><Link to="/report" className="text-jerry-300 hover:text-white text-sm transition-colors">Report Abuse</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Support</h4>
              <ul className="space-y-2">
                <li><Link to="/contact" className="text-jerry-300 hover:text-white text-sm transition-colors">Help Center</Link></li>
                <li><a href="mailto:support@jerry.app" className="text-jerry-300 hover:text-white text-sm transition-colors">Email Support</a></li>
              </ul>
            </div>
          </div>
          <div className="text-center text-jerry-400 text-sm">
            <p>&copy; {new Date().getFullYear()} JERRY. All rights reserved. Not affiliated with Tom and Jerry.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

const features = [
  {
    title: 'Private Profiles',
    description: 'Control who sees your profile. Choose between public, connections-only, or private visibility settings.',
    icon: <svg className="w-6 h-6 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>,
  },
  {
    title: 'Real-time Chat',
    description: 'Private messaging with mutual consent. Only chat with people you have accepted connections with.',
    icon: <svg className="w-6 h-6 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>,
  },
  {
    title: 'Smart Discovery',
    description: 'Find people with shared interests and languages. No location tracking or sensitive data exposure.',
    icon: <svg className="w-6 h-6 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>,
  },
  {
    title: 'Age Verification',
    description: 'Strict 18+ policy with secure age verification. Your birth date is never exposed publicly.',
    icon: <svg className="w-6 h-6 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
  },
  {
    title: 'Safety First',
    description: 'Block users, report abuse, and control your experience. Moderators ensure community guidelines are followed.',
    icon: <svg className="w-6 h-6 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" /></svg>,
  },
  {
    title: 'Full Control',
    description: 'Manage your data, export your information, or delete your account entirely. You are in charge.',
    icon: <svg className="w-6 h-6 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  },
];

const privacyFeatures = [
  'No location tracking',
  'End-to-end encrypted messages',
  'Profile visibility controls',
  'No third-party data sharing',
  'GDPR compliant',
  'Regular security audits',
];