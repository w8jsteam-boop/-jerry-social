import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

export default function SignUp() {
  const [step, setStep] = useState<'account' | 'age' | 'profile'>('account');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { signUp, verifyAge, updateProfile } = useAuth();
  const navigate = useNavigate();

  const handleAccountSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (!agreeToTerms) {
      setError('You must agree to the Terms of Service and Privacy Policy');
      return;
    }

    setStep('age');
  };

  const handleAgeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!birthDate) {
      setError('Please enter your date of birth');
      return;
    }

    if (!verifyAge(birthDate)) {
      setError('You must be 18 or older to use JERRY');
      return;
    }

    setStep('profile');
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!username.trim()) {
      setError('Please choose a username');
      setLoading(false);
      return;
    }

    const result = await signUp(email, password);
    
    if (!result.error) {
      // Profile will be created by database trigger
      await updateProfile({
        username: username.trim(),
        display_name: displayName.trim() || null,
        birth_date: birthDate,
        age_verified: true,
      });
      
      navigate('/login?verified=pending');
    }
    setLoading(false);
  };

  const inputClass = "w-full px-4 py-3 bg-white/5 border border-jerry-400/20 text-white placeholder-jerry-200/40 rounded-xl focus:outline-none focus:border-jerry-400/60 focus:bg-white/10 focus:ring-1 focus:ring-jerry-400/30 transition-all duration-200";

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-jerry-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-jerry-400/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-jerry-500 to-jerry-700 flex items-center justify-center shadow-lg shadow-jerry-500/30">
              <svg viewBox="0 0 24 24" className="w-7 h-7 text-white" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
            </div>
          </Link>
          <h1 className="text-3xl font-display font-bold text-white">Join JERRY</h1>
          <p className="text-jerry-200/70 mt-2">Create your private social connection profile</p>
        </div>

        {/* Steps Indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {['account', 'age', 'profile'].map((s, i) => (
            <React.Fragment key={s}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
                step === s 
                  ? 'bg-jerry-500 text-white shadow-lg shadow-jerry-500/30' 
                  : ['age', 'profile'].indexOf(step) > i
                    ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                    : 'bg-jerry-900/50 text-jerry-400 border border-jerry-800/30'
              }`}>
                {['age', 'profile'].indexOf(step) > i ? '✓' : i + 1}
              </div>
              {i < 2 && <div className={`h-0.5 w-12 rounded ${['age', 'profile'].indexOf(step) > i ? 'bg-green-500/50' : 'bg-jerry-800/50'}`} />}
            </React.Fragment>
          ))}
        </div>

        <div className="glass-card p-8">
          {step === 'account' && (
            <form onSubmit={handleAccountSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-jerry-200 mb-2">Email address</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className={inputClass}
                  placeholder="you@example.com"
                  required
                  autoComplete="email"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-jerry-200 mb-2">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className={inputClass}
                  placeholder="At least 8 characters"
                  required
                  autoComplete="new-password"
                  minLength={8}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-jerry-200 mb-2">Confirm password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  className={inputClass}
                  placeholder="Repeat your password"
                  required
                  autoComplete="new-password"
                />
              </div>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreeToTerms}
                  onChange={e => setAgreeToTerms(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded border-jerry-400/30 bg-white/5 text-jerry-500 focus:ring-jerry-400"
                />
                <span className="text-sm text-jerry-200/70">
                  I agree to the{' '}
                  <Link to="/terms" className="text-jerry-300 hover:text-jerry-200 underline">Terms of Service</Link>
                  {' '}and{' '}
                  <Link to="/privacy" className="text-jerry-300 hover:text-jerry-200 underline">Privacy Policy</Link>,
                  and confirm I am 18 years or older.
                </span>
              </label>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <button type="submit" className="btn-primary w-full">
                Continue
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </form>
          )}

          {step === 'age' && (
            <form onSubmit={handleAgeSubmit} className="space-y-4">
              <div className="text-center mb-4">
                <div className="w-16 h-16 rounded-full bg-jerry-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-jerry-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h2 className="text-xl font-semibold text-white mb-2">Age Verification</h2>
                <p className="text-jerry-200/70 text-sm">
                  JERRY is for adults 18 and older. Your date of birth is stored securely 
                  and never shared with other users.
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-jerry-200 mb-2">Date of birth</label>
                <input
                  type="date"
                  value={birthDate}
                  onChange={e => setBirthDate(e.target.value)}
                  className={inputClass}
                  required
                  max={new Date().toISOString().split('T')[0]}
                />
              </div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <div className="flex gap-3">
                <button type="button" onClick={() => setStep('account')} className="btn-secondary flex-1">
                  Back
                </button>
                <button type="submit" className="btn-primary flex-1">
                  Verify Age
                </button>
              </div>
            </form>
          )}

          {step === 'profile' && (
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div className="text-center mb-4">
                <h2 className="text-xl font-semibold text-white mb-2">Set up your profile</h2>
                <p className="text-jerry-200/70 text-sm">Choose how you appear on JERRY</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-jerry-200 mb-2">Username *</label>
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  className={inputClass}
                  placeholder="choose_your_username"
                  required
                  autoComplete="username"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-jerry-200 mb-2">Display name (optional)</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                  className={inputClass}
                  placeholder="Your name"
                  autoComplete="name"
                />
              </div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <div className="flex gap-3">
                <button type="button" onClick={() => setStep('age')} className="btn-secondary flex-1">
                  Back
                </button>
                <button type="submit" disabled={loading} className="btn-primary flex-1">
                  {loading ? 'Creating account...' : 'Create Account'}
                </button>
              </div>
            </form>
          )}
        </div>

        <p className="text-center mt-6 text-jerry-300 text-sm">
          Already have an account?{' '}
          <Link to="/login" className="text-jerry-200 hover:text-white font-medium underline underline-offset-2">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}